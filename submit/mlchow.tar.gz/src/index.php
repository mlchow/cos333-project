<!DOCTYPE html>
<html>
<head><title>Progress Report</title></head>
<body>
  <h1>Welcome to Progress Report</h1>
  <p>Please upload your transcript.</p>
  <form action="parse_transcript.py" method="post"><input type="file" accept=".pdf" name="transcript"></input></form>
</body>
</html>
